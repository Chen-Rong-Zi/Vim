# coding=utf-8
import time

fd = open('welcome.txt','a+',encoding='utf-8')

with open('Welcome.md','r',encoding='utf-8') as f:
    lines = f.readlines()
    # print(lines)

for line in lines:
    for w in line:
        fd.write(w)
        print(w,end='')
        time.sleep(0.3)

fd.close()

