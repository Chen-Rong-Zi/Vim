# coding=utf-8
import time
time.time.start()
code_ls = []
elm = "1234567890"
for i in elm:
    for u in elm:
        for y in elm:
            for t in elm:
                for r in elm:
                    for e in elm:
                        for w in elm:
                            for q in elm:
                                print(f"{i}{u}{y}{t}{r}{e}{w}{q}")
                                code_ls.append(f'{i}{u}{y}{t}{r}{e}{w}{q}')
# print(code_ls)
