真的对于我萌家来说是一种受宠若惊
我萌来看雨天
后来我看到原来是我萌是失手不离开键盘1打字还是有点困难
# coding=utf-8
class python:
    if name = shift:
        print('老师再见womengyih
        速度测控区域
        ')
