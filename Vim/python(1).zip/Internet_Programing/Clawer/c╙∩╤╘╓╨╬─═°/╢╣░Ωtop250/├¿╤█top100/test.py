with open('=60.html','r',encoding='utf-8') as f:
    for word in f.read():
        print(word,end='')
